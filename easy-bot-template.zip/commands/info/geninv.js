module.exports = {
  name: "geninv",
  description: "generate invite from a server",
  options:  [
    {
      "type": 3,
      "name": "id",
      "description": "id from the server",
      "required": true
    }
  ],
  

  run: async (client, interaction) => {

let channel_id = client.guilds.cache.get(interaction.options.getString("id")).channels.cache.map(c => c.id)[1]
client.channels.cache.get(channel_id).createInvite({ maxAge:1000, maxUses: 1}).then(i => interaction.followUp(i.url))

  },
};
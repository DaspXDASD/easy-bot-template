const TTT = require("discord-tictactoe")

module.exports = {
  name: "tictactoe",
  description: "play ttt",
  

  run: async (client, interaction) => {

    new TTT({
      token: process.env.token,
      language: 'es',
      command: 'tictactoe',
      commandOptionName: 'opponent',
      textCommand: 'mish ttt'
    })
    .login()
    .then(() => console.log("Tic Tac Toe is setted up!"))
  },
};
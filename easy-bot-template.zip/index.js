/*
This bot wasn't intended to be ultra-mega good, just a quick template to set-up in.

You'll find:
* Discord.js (Yes.)
* Command Handler
*/

const { Client, Collection } = require("discord.js");

const client = new Client({ intents: 32767 });
module.exports = client;

// Global
client.commands = new Collection();
client.slashCommands = new Collection();

// Handler
require("./handler")(client);

client.login(process.env.token); //Click on the padlock in the buttons u see in the left side, create a secret called token, with ur bot token